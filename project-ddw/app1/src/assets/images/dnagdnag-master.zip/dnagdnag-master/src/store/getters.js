/* 
包含n个基于state状态数据的getter计算属性方法的对象
*/
export default {
  
}