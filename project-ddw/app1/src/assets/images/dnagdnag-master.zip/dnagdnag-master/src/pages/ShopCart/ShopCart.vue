<template>
    <div>
        ShopCart
    </div>
</template>
<script>
export default {

}
</script>
<style lang='stylus'>

</style>