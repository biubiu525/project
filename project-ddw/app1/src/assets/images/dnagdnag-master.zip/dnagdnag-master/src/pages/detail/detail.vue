<template>
  <div>
<Header></Header>
<Footer></Footer>
  </div>
 
</template>

<script type="text/ecmascript-6">
 import Header from '../../components/header/header'
 import Footer from '../../components/footer/footer'
  export default {
      components:{
            Header ,Footer
      },
  }
</script>

<style lang="stylus" rel="stylesheet/stylus" scoped>

 
</style>
