/* 
包含n个mutation函数名常量
*/


export const RECEIVE_TOKEN = 'receive_token'
export const RECEIVE_USER = 'receive_user'
export const RESET_USER = 'reset_user'
export const RESET_TOKEN = 'reset_token'