<template>
  <div>
    <Pull/>
    <bar></bar>
    <Common/>
    <Ball/>
    <Shop/>
  </div>
</template>

<script type="text/ecmascript-6">
import Pull from "./Pull"
import Bar from "./Bar"
import Common from "./Common"
import Ball from "./Ball"
import Shop from "./Shop"
  export default {
     components:{
      Pull,
      Bar,
      Common,
      Ball
    }
  }
</script>

<style stylus lang="stylus" rel="stylesheet/stylus">

 
</style>
