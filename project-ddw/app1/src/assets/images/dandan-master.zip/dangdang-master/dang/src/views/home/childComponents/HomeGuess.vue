<template>
  <div class="home-guess">
    <img style="height: 20px" src="~assets/images/home/check.png" alt="">
    <span style="line-height: 100px">根据您的偏好猜您可能喜欢</span>
  </div>
</template>

<script>
  export default {
    name: "HomeGuess"
  }
</script>

<style scoped>
  .home-guess{
    background-color: #eff4fa;
    text-align: center;
    height: 100px;
    vertical-align: middle;
  }
</style>