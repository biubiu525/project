<template>
  <div>
    <h2>
      值得买
    </h2>
  </div>
</template>

<script>
  export default {
    name: "Worth"
  }
</script>

<style scoped>

</style>