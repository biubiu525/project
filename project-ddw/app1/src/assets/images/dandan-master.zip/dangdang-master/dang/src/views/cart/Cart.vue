<template>
  <div>
    <h2>购物车</h2>
  </div>
</template>

<script>
  export default {
    name: "Cart"
  }
</script>

<style scoped>

</style>